#!/bin/bash
chmod +x install.sh
npm install node-telegram-bot-api
node yanzz.js